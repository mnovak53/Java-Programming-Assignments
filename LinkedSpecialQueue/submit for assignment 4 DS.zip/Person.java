package assignment5;

/*
 * COSC 2100 - Fall '23
 * A class to create Person objects.
 * Instance variable - age (int type)
 * @author Dr. jain
 */

public class Person {
	protected int age; //age of a Person object
	
	public Person(int age) {
		this.age = age;
	}

}
